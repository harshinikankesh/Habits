# HabitForge — Deployment Guide

## What you're deploying

| Route | Purpose |
|-------|---------|
| `/` | Public landing page |
| `/track?id=TOKEN` | User tracker (invite-only) |
| `/admin` | Your private admin console |
| `/api/admin` | Admin REST API (password-protected) |
| `/api/user` | User data API |

---

## Step 1 — Push to GitHub

```bash
cd habitforge
git init
git add .
git commit -m "Initial HabitForge commit"
```

Go to https://github.com/new → create a repo (keep it **private**) → follow the "push existing" instructions shown there.

---

## Step 2 — Deploy to Vercel

1. Go to **https://vercel.com** → Sign in (or sign up free)
2. Click **"Add New Project"** → Import your GitHub repo
3. Vercel auto-detects Next.js — hit **Deploy** (don't add env vars yet)
4. Wait ~2 min for the first deployment to complete

---

## Step 3 — Add Vercel KV (database)

1. In your Vercel project dashboard → **Storage** tab
2. Click **Create Database** → choose **KV (Redis)**
3. Name it `habitforge-db`, click **Create**
4. Vercel automatically adds `KV_URL`, `KV_REST_API_URL`, `KV_REST_API_TOKEN`, and `KV_REST_API_READ_ONLY_TOKEN` to your project's environment variables

---

## Step 4 — Set your admin password

1. In your Vercel project → **Settings** → **Environment Variables**
2. Add a new variable:
   - **Key:** `ADMIN_SECRET`
   - **Value:** `your-secure-password` (make it strong!)
   - **Environments:** Production, Preview, Development
3. Click **Save**

---

## Step 5 — Redeploy

After adding env vars:
1. Go to **Deployments** tab
2. Click the `⋯` menu on the latest deployment → **Redeploy**
3. Wait ~1 min

Your app is now live! 🎉

---

## Step 6 — First use

1. Visit `https://your-app.vercel.app/admin`
2. Enter your admin password
3. Go to **Links** tab → **Generate Unique Link**
4. Copy and send the link to whoever you want to track with
5. Use **Habits** tab to manage the master habit list
6. Use **Users** tab to award stars and manage per-user habits

---

## Local development (optional)

```bash
npm install
# Install Vercel CLI
npm install -g vercel
vercel login
vercel link           # link to your project
vercel env pull       # download env vars to .env.local
npm run dev           # starts on http://localhost:3000
```

---

## Custom domain (optional)

In Vercel dashboard → **Settings** → **Domains** → add your own domain.

---

## Security notes

- Admin console is protected by the `ADMIN_SECRET` password — never share it
- Each user link is a unique random token (12 chars, 62^12 possibilities)
- Users can only see their own data — not each other's
- You can grant selected users visibility into your stats from the user detail panel

---

## Updating the app later

Push any changes to GitHub — Vercel auto-deploys on every commit.

```bash
git add .
git commit -m "Update habits"
git push
```
