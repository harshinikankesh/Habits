"use client";
import { useEffect, useState, useCallback, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { UserRecord, Habit, DEFAULT_HABITS } from "@/lib/store";
import HabitCard from "@/components/HabitCard";
import ProgressRing from "@/components/ProgressRing";
import StarRating from "@/components/StarRating";
import Confetti from "@/components/Confetti";

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function getStreak(completions: Record<string, string[]>, habitId: string) {
  let streak = 0;
  const d = new Date();
  for (let i = 0; i < 30; i++) {
    const key = new Date(d.getTime() - i * 86400000).toISOString().slice(0, 10);
    if (completions[key]?.includes(habitId)) streak++;
    else break;
  }
  return streak;
}

function getWeeklyPct(completions: Record<string, string[]>, totalHabits: number) {
  let total = 0, done = 0;
  for (let i = 0; i < 7; i++) {
    const key = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
    total += totalHabits;
    done += (completions[key] || []).length;
  }
  return total === 0 ? 0 : Math.round((done / total) * 100);
}

function TrackPage() {
  const params = useSearchParams();
  const router = useRouter();
  const token = params.get("id");

  const [user, setUser] = useState<UserRecord | null>(null);
  const [baseHabits, setBaseHabits] = useState<Habit[]>([]);
  const [loading, setLoading] = useState(true);
  const [nameInput, setNameInput] = useState("");
  const [showNameModal, setShowNameModal] = useState(false);
  const [todayDone, setTodayDone] = useState<Set<string>>(new Set());
  const [confetti, setConfetti] = useState(false);
  const [tab, setTab] = useState<"today" | "habits" | "progress">("today");
  const [editHabitMode, setEditHabitMode] = useState(false);
  const [newHabitLabel, setNewHabitLabel] = useState("");
  const [newHabitEmoji, setNewHabitEmoji] = useState("⭐");
  const [savingHabit, setSavingHabit] = useState(false);

  useEffect(() => {
    if (!token) { router.push("/"); return; }
    fetch(`/api/user?id=${token}`)
      .then(r => r.json())
      .then(d => {
        if (d.user) {
          setUser(d.user);
          setBaseHabits(d.baseHabits || []);
          const today = d.user.completions[todayKey()] || [];
          setTodayDone(new Set(today));
          if (!d.user.name) setShowNameModal(true);
        }
        setLoading(false);
      });
  }, [token]);

  const toggle = useCallback(async (habitId: string) => {
    if (!user) return;
    const newSet = new Set(todayDone);
    if (newSet.has(habitId)) newSet.delete(habitId);
    else {
      newSet.add(habitId);
      if (newSet.size === user.habits.length) {
        setConfetti(true);
        setTimeout(() => setConfetti(false), 100);
      }
    }
    setTodayDone(newSet);

    const r = await fetch("/api/user", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: user.id, action: "toggleCompletion", date: todayKey(), habitId }),
    });
    const d = await r.json();
    if (d.user) setUser(d.user);
  }, [user, todayDone]);

  async function saveName() {
    if (!user || !nameInput.trim()) return;
    const r = await fetch("/api/user", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: user.id, action: "setName", name: nameInput.trim() }),
    });
    const d = await r.json();
    if (d.user) setUser(d.user);
    setShowNameModal(false);
  }

  async function addCustomHabit() {
    if (!user || !newHabitLabel.trim()) return;
    setSavingHabit(true);
    const newHabit: Habit = {
      id: `c${Date.now()}`,
      label: newHabitLabel.trim(),
      emoji: newHabitEmoji,
      category: "Custom",
    };
    const updated = [...user.habits, newHabit];
    const r = await fetch("/api/user", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: user.id, action: "setUserHabits", habits: updated }),
    });
    const d = await r.json();
    if (d.user) setUser(d.user);
    setNewHabitLabel("");
    setNewHabitEmoji("⭐");
    setSavingHabit(false);
  }

  async function removeHabit(habitId: string) {
    if (!user) return;
    const updated = user.habits.filter(h => h.id !== habitId);
    const r = await fetch("/api/user", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: user.id, action: "setUserHabits", habits: updated }),
    });
    const d = await r.json();
    if (d.user) setUser(d.user);
  }

  async function addBaseHabit(habit: Habit) {
    if (!user || user.habits.find(h => h.id === habit.id)) return;
    const updated = [...user.habits, habit];
    const r = await fetch("/api/user", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: user.id, action: "setUserHabits", habits: updated }),
    });
    const d = await r.json();
    if (d.user) setUser(d.user);
  }

  if (loading) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div style={{ textAlign: "center" }}>
        <div style={{ fontSize: 40, animation: "float 2s ease-in-out infinite" }}>✦</div>
        <p style={{ color: "var(--text-muted)", marginTop: 12, fontSize: 13 }}>Loading your space…</p>
      </div>
    </div>
  );

  if (!user) return null;

  const today = todayKey();
  const totalHabits = user.habits.length;
  const completedToday = todayDone.size;
  const pct = totalHabits === 0 ? 0 : Math.round((completedToday / totalHabits) * 100);
  const weekPct = getWeeklyPct(user.completions, totalHabits);

  const dateStr = new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" });

  return (
    <div style={{ minHeight: "100vh", paddingBottom: 80 }}>
      {/* Background orbs */}
      <div className="orb" style={{ width: 400, height: 400, background: "var(--gold)", top: -100, right: -100, opacity: 0.08 }} />
      <div className="orb" style={{ width: 300, height: 300, background: "var(--emerald)", bottom: 100, left: -80, opacity: 0.07 }} />

      {/* Name modal */}
      {showNameModal && (
        <div className="modal-backdrop">
          <div className="glass fade-in-up" style={{ borderRadius: 20, padding: 36, maxWidth: 420, width: "90%", textAlign: "center" }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>✦</div>
            <h2 style={{ fontFamily: "'Playfair Display', serif", fontSize: 26, marginBottom: 8 }}>Welcome aboard</h2>
            <p style={{ color: "var(--text-muted)", fontSize: 14, marginBottom: 24 }}>What should we call you?</p>
            <input
              className="input-field"
              style={{ padding: "12px 16px", marginBottom: 16, fontSize: 15 }}
              placeholder="Your name…"
              value={nameInput}
              onChange={e => setNameInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && saveName()}
              autoFocus
            />
            <button className="btn-gold" style={{ padding: "12px 32px", fontSize: 14, width: "100%" }} onClick={saveName}>
              Begin my journey →
            </button>
          </div>
        </div>
      )}

      <div style={{ maxWidth: 640, margin: "0 auto", padding: "24px 20px" }}>
        {/* Header */}
        <div className="fade-in-up" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 28 }}>
          <div>
            <p style={{ fontSize: 11, color: "var(--text-muted)", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 4 }}>
              {dateStr}
            </p>
            <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, lineHeight: 1.2 }}>
              {user.name ? `Hey, ${user.name}` : "Your Dashboard"}
            </h1>
          </div>
          <div style={{ position: "relative" }}>
            <ProgressRing pct={pct} size={72} color={pct === 100 ? "#f5c842" : "var(--emerald)"} />
            <Confetti trigger={confetti} />
          </div>
        </div>

        {/* Stars from admin */}
        {user.stars > 0 && (
          <div className="glass-gold fade-in-up-delay-1" style={{
            borderRadius: 14, padding: "16px 20px", marginBottom: 20,
            display: "flex", alignItems: "center", gap: 16
          }}>
            <div>
              <p style={{ fontSize: 11, color: "var(--gold)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 6 }}>Admin Recognition</p>
              <StarRating value={user.stars} readOnly size={22} note={user.starNote} />
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="fade-in-up-delay-1" style={{
          display: "flex", background: "rgba(255,255,255,0.03)", borderRadius: 12,
          padding: 4, marginBottom: 24, border: "1px solid var(--border)"
        }}>
          {(["today", "habits", "progress"] as const).map(t => (
            <button
              key={t}
              className={`tab-pill ${tab === t ? "active" : ""}`}
              style={{ flex: 1 }}
              onClick={() => setTab(t)}
            >
              {t === "today" ? "📅 Today" : t === "habits" ? "⚙️ My Habits" : "📊 Progress"}
            </button>
          ))}
        </div>

        {/* TODAY TAB */}
        {tab === "today" && (
          <div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
              <span style={{ fontSize: 13, color: "var(--text-muted)" }}>
                {completedToday} of {totalHabits} completed
              </span>
              {pct === 100 && (
                <span style={{ fontSize: 13, color: "var(--gold)", fontWeight: 600 }}>🏆 Perfect day!</span>
              )}
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {user.habits.map((h, i) => (
                <HabitCard
                  key={h.id}
                  habit={h}
                  completed={todayDone.has(h.id)}
                  onToggle={() => toggle(h.id)}
                  streak={getStreak(user.completions, h.id)}
                  animDelay={i * 60}
                />
              ))}
            </div>

            {user.habits.length === 0 && (
              <div style={{ textAlign: "center", padding: "48px 20px", color: "var(--text-muted)" }}>
                <p style={{ fontSize: 32, marginBottom: 12 }}>🌱</p>
                <p>No habits yet. Go to "My Habits" to set up yours.</p>
              </div>
            )}
          </div>
        )}

        {/* HABITS TAB */}
        {tab === "habits" && (
          <div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
              <h3 style={{ fontSize: 15, fontWeight: 600 }}>Your habit list</h3>
            </div>

            {/* Current habits */}
            <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 24 }}>
              {user.habits.map((h, i) => (
                <div key={h.id} className="fade-in-up" style={{
                  animationDelay: `${i * 40}ms`,
                  display: "flex", alignItems: "center", gap: 12,
                  background: "rgba(255,255,255,0.02)", border: "1px solid var(--border)",
                  borderRadius: 12, padding: "11px 14px"
                }}>
                  <span style={{ fontSize: 20 }}>{h.emoji}</span>
                  <div style={{ flex: 1 }}>
                    <p style={{ fontSize: 14, fontWeight: 500 }}>{h.label}</p>
                    <p style={{ fontSize: 11, color: "var(--text-muted)" }}>{h.category}</p>
                  </div>
                  <button
                    onClick={() => removeHabit(h.id)}
                    style={{ background: "none", border: "none", color: "var(--text-muted)", cursor: "pointer", fontSize: 16, padding: "0 4px" }}
                    title="Remove"
                  >×</button>
                </div>
              ))}
            </div>

            {/* Add base habits not yet in list */}
            {baseHabits.filter(b => !user.habits.find(h => h.id === b.id)).length > 0 && (
              <div style={{ marginBottom: 24 }}>
                <p style={{ fontSize: 12, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 10 }}>Add from master list</p>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                  {baseHabits.filter(b => !user.habits.find(h => h.id === b.id)).map(h => (
                    <button
                      key={h.id}
                      className="btn-ghost"
                      style={{ padding: "7px 14px", fontSize: 13, display: "flex", alignItems: "center", gap: 6 }}
                      onClick={() => addBaseHabit(h)}
                    >
                      <span>{h.emoji}</span> {h.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Add custom habit */}
            <div className="glass" style={{ borderRadius: 14, padding: 18 }}>
              <p style={{ fontSize: 12, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 12 }}>Add custom habit</p>
              <div style={{ display: "flex", gap: 10, marginBottom: 10 }}>
                <input
                  className="input-field"
                  style={{ padding: "10px 14px", fontSize: 14 }}
                  placeholder="Habit name…"
                  value={newHabitLabel}
                  onChange={e => setNewHabitLabel(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && addCustomHabit()}
                />
                <input
                  className="input-field"
                  style={{ padding: "10px 14px", fontSize: 14, width: 58, textAlign: "center" }}
                  value={newHabitEmoji}
                  onChange={e => setNewHabitEmoji(e.target.value)}
                  maxLength={2}
                />
              </div>
              <button
                className="btn-gold"
                style={{ padding: "10px 24px", fontSize: 13, width: "100%" }}
                onClick={addCustomHabit}
                disabled={savingHabit || !newHabitLabel.trim()}
              >
                {savingHabit ? "Adding…" : "+ Add habit"}
              </button>
            </div>
          </div>
        )}

        {/* PROGRESS TAB */}
        {tab === "progress" && (
          <div>
            {/* Week overview */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 24 }}>
              <div className="glass" style={{ borderRadius: 14, padding: 18, textAlign: "center" }}>
                <ProgressRing pct={weekPct} size={72} color="var(--gold)" />
                <p style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 10 }}>This week</p>
              </div>
              <div className="glass" style={{ borderRadius: 14, padding: 18 }}>
                <p style={{ fontSize: 11, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 12 }}>Top streaks</p>
                {user.habits.slice(0, 3).map(h => {
                  const s = getStreak(user.completions, h.id);
                  return (
                    <div key={h.id} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
                      <span style={{ fontSize: 16 }}>{h.emoji}</span>
                      <span style={{ flex: 1, fontSize: 12, color: "var(--text-sub)" }}>{h.label}</span>
                      <span style={{ fontSize: 12, color: "#f5c842", fontFamily: "'DM Mono', monospace" }}>🔥 {s}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Last 7 days grid */}
            <div className="glass" style={{ borderRadius: 14, padding: 18 }}>
              <p style={{ fontSize: 12, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 16 }}>Last 7 days</p>
              <div style={{ overflowX: "auto" }}>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead>
                    <tr>
                      <th style={{ fontSize: 11, color: "var(--text-muted)", textAlign: "left", paddingBottom: 8, fontWeight: 500, minWidth: 120 }}>Habit</th>
                      {Array.from({ length: 7 }, (_, i) => {
                        const d = new Date(Date.now() - (6 - i) * 86400000);
                        return (
                          <th key={i} style={{ fontSize: 11, color: "var(--text-muted)", fontWeight: 500, paddingBottom: 8, width: 36, textAlign: "center" }}>
                            {d.toLocaleDateString("en", { weekday: "narrow" })}
                          </th>
                        );
                      })}
                    </tr>
                  </thead>
                  <tbody>
                    {user.habits.map(h => (
                      <tr key={h.id}>
                        <td style={{ fontSize: 12, color: "var(--text-sub)", paddingBottom: 8, paddingRight: 12 }}>
                          {h.emoji} {h.label}
                        </td>
                        {Array.from({ length: 7 }, (_, i) => {
                          const k = new Date(Date.now() - (6 - i) * 86400000).toISOString().slice(0, 10);
                          const done = user.completions[k]?.includes(h.id);
                          return (
                            <td key={i} style={{ textAlign: "center", paddingBottom: 8 }}>
                              <div style={{
                                width: 22, height: 22, borderRadius: 6, margin: "0 auto",
                                background: done ? "var(--emerald)" : "rgba(255,255,255,0.05)",
                                border: `1px solid ${done ? "var(--emerald)" : "var(--border)"}`,
                                display: "flex", alignItems: "center", justifyContent: "center",
                              }}>
                                {done && (
                                  <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                                    <polyline points="2,5 4,7.5 8,2.5" stroke="#0a0a0f" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
                                  </svg>
                                )}
                              </div>
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function TrackPageWrapper() {
  return (
    <Suspense>
      <TrackPage />
    </Suspense>
  );
}
