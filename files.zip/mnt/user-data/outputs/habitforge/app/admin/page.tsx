"use client";
import { useEffect, useState, useCallback } from "react";
import { UserRecord, Habit, DEFAULT_HABITS, AdminState } from "@/lib/store";
import StarRating from "@/components/StarRating";
import ProgressRing from "@/components/ProgressRing";

const EMOJIS = ["🧘","📖","💧","🏋️","📵","🌙","✍️","🚿","🥗","🎯","💪","🧠","🌿","☀️","🎨","🎵","💼","📝"];

function pct7(user: UserRecord) {
  let t = 0, d = 0;
  for (let i = 0; i < 7; i++) {
    const k = new Date(Date.now() - i * 86400000).toISOString().slice(0, 10);
    t += user.habits.length;
    d += (user.completions[k] || []).length;
  }
  return t === 0 ? 0 : Math.round((d / t) * 100);
}

function todayKey() { return new Date().toISOString().slice(0, 10); }

export default function AdminPage() {
  const [authed, setAuthed] = useState(false);
  const [tokenInput, setTokenInput] = useState("");
  const [token, setToken] = useState("");
  const [state, setState] = useState<AdminState | null>(null);
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState<"users" | "habits" | "links" | "analytics">("users");
  const [selectedUser, setSelectedUser] = useState<UserRecord | null>(null);
  const [savingStars, setSavingStars] = useState(false);
  const [starNote, setStarNote] = useState("");
  const [newHabitLabel, setNewHabitLabel] = useState("");
  const [newHabitEmoji, setNewHabitEmoji] = useState("⭐");
  const [newHabitCategory, setNewHabitCategory] = useState("Mind");
  const [generatedLink, setGeneratedLink] = useState("");
  const [copied, setCopied] = useState(false);
  const [editingUser, setEditingUser] = useState<string | null>(null);
  const [userHabitLabel, setUserHabitLabel] = useState("");
  const [userHabitEmoji, setUserHabitEmoji] = useState("⭐");

  const baseUrl = typeof window !== "undefined" ? window.location.origin : "";

  const load = useCallback(async (t: string) => {
    setLoading(true);
    const r = await fetch("/api/admin", { headers: { "x-admin-token": t } });
    if (r.status === 401) { alert("Wrong password"); setLoading(false); return; }
    const d = await r.json();
    setState(d);
    setAuthed(true);
    setLoading(false);
  }, []);

  async function login() {
    if (!tokenInput.trim()) return;
    setToken(tokenInput.trim());
    await load(tokenInput.trim());
  }

  async function api(action: object) {
    const r = await fetch("/api/admin", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-admin-token": token },
      body: JSON.stringify(action),
    });
    return r.json();
  }

  async function setUserStars(userId: string, stars: number, note: string) {
    setSavingStars(true);
    await api({ action: "setUserStars", userId, stars, note });
    await load(token);
    setSavingStars(false);
  }

  async function addBaseHabit() {
    if (!state || !newHabitLabel.trim()) return;
    const newH: Habit = {
      id: `h${Date.now()}`,
      label: newHabitLabel.trim(),
      emoji: newHabitEmoji,
      category: newHabitCategory,
    };
    const updated = [...state.baseHabits, newH];
    await api({ action: "setBaseHabits", habits: updated });
    setNewHabitLabel(""); setNewHabitEmoji("⭐");
    await load(token);
  }

  async function removeBaseHabit(id: string) {
    if (!state) return;
    await api({ action: "setBaseHabits", habits: state.baseHabits.filter(h => h.id !== id) });
    await load(token);
  }

  async function generateLink() {
    const r = await fetch("/api/user", { method: "PUT", headers: { "x-admin-token": token } });
    const d = await r.json();
    setGeneratedLink(`${baseUrl}/track?id=${d.id}`);
  }

  async function copyLink(link: string) {
    await navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  async function setUserAccess(userId: string, allow: boolean) {
    await api({ action: "setUserAccess", userId, allow });
    await load(token);
  }

  async function deleteUser(userId: string) {
    if (!confirm("Delete this user?")) return;
    await api({ action: "deleteUser", userId });
    setSelectedUser(null);
    await load(token);
  }

  async function addHabitToUser(userId: string) {
    if (!state || !userHabitLabel.trim()) return;
    const user = state.users.find(u => u.id === userId);
    if (!user) return;
    const newH: Habit = { id: `c${Date.now()}`, label: userHabitLabel.trim(), emoji: userHabitEmoji, category: "Custom" };
    await api({ action: "setUserHabits", userId, habits: [...user.habits, newH] });
    setUserHabitLabel(""); setUserHabitEmoji("⭐");
    await load(token);
    const updated = (await (await fetch("/api/admin", { headers: { "x-admin-token": token } })).json());
    setState(updated);
    setSelectedUser(updated.users.find((u: UserRecord) => u.id === userId) || null);
  }

  async function removeHabitFromUser(userId: string, habitId: string) {
    if (!state) return;
    const user = state.users.find(u => u.id === userId);
    if (!user) return;
    await api({ action: "setUserHabits", userId, habits: user.habits.filter(h => h.id !== habitId) });
    await load(token);
    const updated = state.users.find(u => u.id === userId);
    if (updated) setSelectedUser({ ...updated, habits: updated.habits.filter(h => h.id !== habitId) });
  }

  // Login screen
  if (!authed) return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div className="orb" style={{ width: 500, height: 500, background: "var(--gold)", top: -150, left: -100, opacity: 0.07 }} />
      <div className="glass fade-in-up" style={{ borderRadius: 24, padding: 44, maxWidth: 400, width: "90%", textAlign: "center" }}>
        <div style={{ fontSize: 52, marginBottom: 20 }}>✦</div>
        <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: 28, marginBottom: 6 }}>HabitForge</h1>
        <p style={{ color: "var(--text-muted)", fontSize: 13, marginBottom: 28 }}>Admin Console</p>
        <input
          className="input-field"
          style={{ padding: "12px 16px", marginBottom: 14, fontSize: 15 }}
          type="password"
          placeholder="Admin password…"
          value={tokenInput}
          onChange={e => setTokenInput(e.target.value)}
          onKeyDown={e => e.key === "Enter" && login()}
          autoFocus
        />
        <button className="btn-gold" style={{ padding: "12px 32px", width: "100%", fontSize: 14 }} onClick={login}>
          {loading ? "Checking…" : "Enter Admin →"}
        </button>
      </div>
    </div>
  );

  if (!state) return null;

  return (
    <div style={{ minHeight: "100vh" }}>
      <div className="orb" style={{ width: 400, height: 400, background: "var(--gold)", top: -120, right: -80, opacity: 0.07 }} />

      {/* Topbar */}
      <div style={{
        borderBottom: "1px solid var(--border)",
        padding: "16px 28px",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        background: "rgba(10,10,15,0.8)", backdropFilter: "blur(16px)",
        position: "sticky", top: 0, zIndex: 50
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <span style={{ fontSize: 22 }} className="shimmer-text">✦</span>
          <div>
            <p style={{ fontFamily: "'Playfair Display', serif", fontSize: 18, fontWeight: 600 }}>HabitForge</p>
            <p style={{ fontSize: 11, color: "var(--text-muted)" }}>Admin Console</p>
          </div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
          <div style={{ textAlign: "right" }}>
            <p style={{ fontSize: 22, fontWeight: 700, color: "var(--gold)", fontFamily: "'DM Mono', monospace" }}>{state.visitCount}</p>
            <p style={{ fontSize: 10, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.08em" }}>Total Visits</p>
          </div>
          <div style={{ width: 1, height: 32, background: "var(--border)" }} />
          <div style={{ textAlign: "right" }}>
            <p style={{ fontSize: 22, fontWeight: 700, color: "var(--emerald)", fontFamily: "'DM Mono', monospace" }}>{state.users.length}</p>
            <p style={{ fontSize: 10, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.08em" }}>Users</p>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "28px 24px" }}>
        {/* Tabs */}
        <div style={{
          display: "flex", background: "rgba(255,255,255,0.03)", borderRadius: 12,
          padding: 4, marginBottom: 28, border: "1px solid var(--border)", width: "fit-content"
        }}>
          {(["users", "habits", "links", "analytics"] as const).map(t => (
            <button
              key={t}
              className={`tab-pill ${tab === t ? "active" : ""}`}
              style={{ minWidth: 100 }}
              onClick={() => setTab(t)}
            >
              {t === "users" ? "👥 Users" : t === "habits" ? "📋 Habits" : t === "links" ? "🔗 Links" : "📈 Analytics"}
            </button>
          ))}
        </div>

        {/* USERS */}
        {tab === "users" && (
          <div style={{ display: "grid", gridTemplateColumns: selectedUser ? "1fr 400px" : "1fr", gap: 20 }}>
            {/* User list */}
            <div>
              {state.users.length === 0 && (
                <div style={{ textAlign: "center", padding: "60px 20px", color: "var(--text-muted)" }}>
                  <p style={{ fontSize: 32, marginBottom: 12 }}>🌱</p>
                  <p>No users yet. Generate a link to invite people.</p>
                </div>
              )}
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {state.users.map((u, i) => {
                  const w7 = pct7(u);
                  const todayDone = (u.completions[todayKey()] || []).length;
                  return (
                    <div
                      key={u.id}
                      className="border-gradient fade-in-up"
                      style={{
                        animationDelay: `${i * 40}ms`,
                        background: selectedUser?.id === u.id ? "rgba(201,168,76,0.05)" : "rgba(255,255,255,0.02)",
                        border: `1px solid ${selectedUser?.id === u.id ? "rgba(201,168,76,0.2)" : "var(--border)"}`,
                        borderRadius: 14, padding: "14px 18px",
                        display: "flex", alignItems: "center", gap: 16,
                        cursor: "pointer", transition: "all 0.2s",
                      }}
                      onClick={() => { setSelectedUser(u); setStarNote(u.starNote || ""); }}
                    >
                      <div style={{
                        width: 40, height: 40, borderRadius: 12,
                        background: "var(--gold-dim)", border: "1px solid rgba(201,168,76,0.2)",
                        display: "flex", alignItems: "center", justifyContent: "center",
                        fontSize: 18, flexShrink: 0
                      }}>
                        {u.name ? u.name.slice(0,1).toUpperCase() : "?"}
                      </div>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <p style={{ fontWeight: 600, fontSize: 14, marginBottom: 2 }}>{u.name || <span style={{ color: "var(--text-muted)", fontStyle: "italic" }}>No name yet</span>}</p>
                        <p style={{ fontSize: 11, color: "var(--text-muted)", fontFamily: "'DM Mono', monospace" }}>{u.id}</p>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
                        <div style={{ textAlign: "center" }}>
                          <p style={{ fontSize: 16, fontWeight: 700, color: "var(--emerald)", fontFamily: "'DM Mono', monospace" }}>{todayDone}</p>
                          <p style={{ fontSize: 10, color: "var(--text-muted)" }}>today</p>
                        </div>
                        <ProgressRing pct={w7} size={44} stroke={3} color="var(--gold)" />
                        {u.stars > 0 && (
                          <div style={{ display: "flex", gap: 2 }}>
                            {Array.from({length: u.stars}, (_, i) => (
                              <svg key={i} width="14" height="14" viewBox="0 0 24 24" fill="#f5c842" stroke="none">
                                <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                              </svg>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* User detail panel */}
            {selectedUser && (
              <div className="glass fade-in-up" style={{ borderRadius: 18, padding: 22, alignSelf: "start", position: "sticky", top: 80 }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
                  <div>
                    <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: 20 }}>
                      {selectedUser.name || "Unnamed user"}
                    </h3>
                    <p style={{ fontSize: 11, color: "var(--text-muted)", fontFamily: "'DM Mono', monospace", marginTop: 3 }}>{selectedUser.id}</p>
                  </div>
                  <button
                    className="btn-ghost"
                    style={{ padding: "6px 10px", fontSize: 18 }}
                    onClick={() => setSelectedUser(null)}
                  >×</button>
                </div>

                <div className="divider" style={{ marginBottom: 18 }} />

                {/* Stats */}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10, marginBottom: 20 }}>
                  {[
                    { label: "7-day", val: `${pct7(selectedUser)}%`, color: "var(--gold)" },
                    { label: "Habits", val: selectedUser.habits.length, color: "var(--emerald)" },
                    { label: "Visits", val: selectedUser.visitCount || 1, color: "var(--text)" },
                  ].map(s => (
                    <div key={s.label} style={{ background: "rgba(255,255,255,0.03)", borderRadius: 10, padding: "10px 12px", textAlign: "center" }}>
                      <p style={{ fontSize: 18, fontWeight: 700, color: s.color, fontFamily: "'DM Mono', monospace" }}>{s.val}</p>
                      <p style={{ fontSize: 10, color: "var(--text-muted)" }}>{s.label}</p>
                    </div>
                  ))}
                </div>

                {/* Star rating */}
                <div style={{ marginBottom: 20 }}>
                  <p style={{ fontSize: 11, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 10 }}>Award Stars</p>
                  <StarRating
                    value={selectedUser.stars}
                    onChange={v => setSelectedUser({ ...selectedUser, stars: v })}
                    size={28}
                  />
                  <input
                    className="input-field"
                    style={{ padding: "9px 12px", fontSize: 13, marginTop: 10 }}
                    placeholder="Star note (optional)…"
                    value={starNote}
                    onChange={e => setStarNote(e.target.value)}
                  />
                  <button
                    className="btn-gold"
                    style={{ padding: "9px 0", fontSize: 13, width: "100%", marginTop: 10 }}
                    onClick={() => setUserStars(selectedUser.id, selectedUser.stars, starNote)}
                    disabled={savingStars}
                  >
                    {savingStars ? "Saving…" : "Save Stars"}
                  </button>
                </div>

                <div className="divider" style={{ marginBottom: 16 }} />

                {/* User habit management */}
                <p style={{ fontSize: 11, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 10 }}>Their Habits</p>
                <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 14, maxHeight: 200, overflowY: "auto" }}>
                  {selectedUser.habits.map(h => (
                    <div key={h.id} style={{ display: "flex", alignItems: "center", gap: 8, background: "rgba(255,255,255,0.03)", borderRadius: 8, padding: "7px 10px" }}>
                      <span style={{ fontSize: 16 }}>{h.emoji}</span>
                      <span style={{ flex: 1, fontSize: 12 }}>{h.label}</span>
                      <button
                        onClick={() => removeHabitFromUser(selectedUser.id, h.id)}
                        style={{ background: "none", border: "none", color: "var(--text-muted)", cursor: "pointer" }}
                      >×</button>
                    </div>
                  ))}
                </div>
                <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
                  <input
                    className="input-field"
                    style={{ padding: "8px 12px", fontSize: 13 }}
                    placeholder="Add habit…"
                    value={userHabitLabel}
                    onChange={e => setUserHabitLabel(e.target.value)}
                  />
                  <input
                    className="input-field"
                    style={{ padding: "8px 10px", fontSize: 13, width: 50, textAlign: "center" }}
                    value={userHabitEmoji}
                    onChange={e => setUserHabitEmoji(e.target.value)}
                    maxLength={2}
                  />
                </div>
                <button
                  className="btn-ghost"
                  style={{ padding: "8px 0", fontSize: 13, width: "100%", marginBottom: 14 }}
                  onClick={() => addHabitToUser(selectedUser.id)}
                  disabled={!userHabitLabel.trim()}
                >+ Add to their list</button>

                <div className="divider" style={{ marginBottom: 14 }} />

                {/* Access control */}
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 14 }}>
                  <div>
                    <p style={{ fontSize: 13, fontWeight: 500 }}>Can see your stats</p>
                    <p style={{ fontSize: 11, color: "var(--text-muted)" }}>Grant mutual visibility</p>
                  </div>
                  <button
                    onClick={() => setUserAccess(selectedUser.id, !selectedUser.allowedToSeeAdmin)}
                    style={{
                      width: 44, height: 24, borderRadius: 99, border: "none", cursor: "pointer",
                      background: selectedUser.allowedToSeeAdmin ? "var(--emerald)" : "rgba(255,255,255,0.1)",
                      position: "relative", transition: "background 0.2s",
                    }}
                  >
                    <div style={{
                      width: 18, height: 18, borderRadius: "50%", background: "white",
                      position: "absolute", top: 3,
                      left: selectedUser.allowedToSeeAdmin ? 23 : 3,
                      transition: "left 0.2s",
                      boxShadow: "0 1px 4px rgba(0,0,0,0.3)"
                    }} />
                  </button>
                </div>

                <button
                  style={{ background: "rgba(248,113,113,0.08)", border: "1px solid rgba(248,113,113,0.2)", color: "var(--rose)", borderRadius: 10, padding: "8px 0", fontSize: 13, width: "100%", cursor: "pointer" }}
                  onClick={() => deleteUser(selectedUser.id)}
                >Delete User</button>
              </div>
            )}
          </div>
        )}

        {/* HABITS TAB */}
        {tab === "habits" && (
          <div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 360px", gap: 24 }}>
              <div>
                <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: 20, marginBottom: 4 }}>Master Habit Library</h3>
                <p style={{ color: "var(--text-muted)", fontSize: 13, marginBottom: 20 }}>These are the default habits all new users start with.</p>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {state.baseHabits.map((h, i) => (
                    <div key={h.id} className="fade-in-up" style={{
                      animationDelay: `${i * 40}ms`,
                      display: "flex", alignItems: "center", gap: 12,
                      background: "rgba(255,255,255,0.02)", border: "1px solid var(--border)",
                      borderRadius: 12, padding: "12px 16px",
                    }}>
                      <span style={{ fontSize: 22 }}>{h.emoji}</span>
                      <div style={{ flex: 1 }}>
                        <p style={{ fontSize: 14, fontWeight: 500 }}>{h.label}</p>
                        <p style={{ fontSize: 11, color: "var(--text-muted)" }}>{h.category}</p>
                      </div>
                      <button
                        onClick={() => removeBaseHabit(h.id)}
                        style={{ background: "none", border: "none", color: "var(--text-muted)", cursor: "pointer", fontSize: 18, padding: "0 4px" }}
                      >×</button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Add habit */}
              <div className="glass" style={{ borderRadius: 18, padding: 22, alignSelf: "start" }}>
                <h4 style={{ fontFamily: "'Playfair Display', serif", fontSize: 17, marginBottom: 16 }}>Add to master list</h4>
                <div style={{ display: "flex", gap: 8, marginBottom: 10 }}>
                  <input
                    className="input-field"
                    style={{ padding: "10px 14px", fontSize: 14 }}
                    placeholder="Habit name…"
                    value={newHabitLabel}
                    onChange={e => setNewHabitLabel(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && addBaseHabit()}
                  />
                  <input
                    className="input-field"
                    style={{ padding: "10px 14px", fontSize: 14, width: 56, textAlign: "center" }}
                    value={newHabitEmoji}
                    onChange={e => setNewHabitEmoji(e.target.value)}
                    maxLength={2}
                  />
                </div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 12 }}>
                  {EMOJIS.map(e => (
                    <button key={e}
                      onClick={() => setNewHabitEmoji(e)}
                      style={{
                        background: newHabitEmoji === e ? "var(--gold-dim)" : "rgba(255,255,255,0.04)",
                        border: `1px solid ${newHabitEmoji === e ? "rgba(201,168,76,0.3)" : "var(--border)"}`,
                        borderRadius: 8, padding: "5px 8px", cursor: "pointer", fontSize: 16
                      }}
                    >{e}</button>
                  ))}
                </div>
                <select
                  className="input-field"
                  style={{ padding: "10px 14px", marginBottom: 12 }}
                  value={newHabitCategory}
                  onChange={e => setNewHabitCategory(e.target.value)}
                >
                  {["Mind","Body","Focus","Rest","Custom"].map(c => <option key={c}>{c}</option>)}
                </select>
                <button className="btn-gold" style={{ padding: "11px 0", width: "100%", fontSize: 14 }} onClick={addBaseHabit}>
                  + Add Habit
                </button>
              </div>
            </div>
          </div>
        )}

        {/* LINKS TAB */}
        {tab === "links" && (
          <div style={{ maxWidth: 600 }}>
            <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, marginBottom: 6 }}>Invite Links</h3>
            <p style={{ color: "var(--text-muted)", fontSize: 13, marginBottom: 24 }}>Generate a unique link for each person you want to track habits with. Each link creates an isolated private session.</p>

            <div className="glass-gold" style={{ borderRadius: 16, padding: 22, marginBottom: 24 }}>
              <p style={{ fontSize: 12, color: "var(--gold)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 12 }}>Generate new link</p>
              <button className="btn-gold" style={{ padding: "12px 28px", fontSize: 14, marginBottom: generatedLink ? 16 : 0 }} onClick={generateLink}>
                ✦ Generate Unique Link
              </button>
              {generatedLink && (
                <div style={{ marginTop: 14 }}>
                  <div style={{
                    background: "rgba(0,0,0,0.3)", borderRadius: 10, padding: "10px 14px",
                    display: "flex", alignItems: "center", gap: 10, marginBottom: 10
                  }}>
                    <span style={{ flex: 1, fontSize: 12, fontFamily: "'DM Mono', monospace", color: "var(--text-sub)", wordBreak: "break-all" }}>
                      {generatedLink}
                    </span>
                    <button
                      className="btn-gold"
                      style={{ padding: "6px 14px", fontSize: 12, flexShrink: 0 }}
                      onClick={() => copyLink(generatedLink)}
                    >
                      {copied ? "✓ Copied" : "Copy"}
                    </button>
                  </div>
                  <p style={{ fontSize: 11, color: "var(--text-muted)" }}>Share this link privately. Anyone with it will get their own isolated tracker.</p>
                </div>
              )}
            </div>

            {/* Existing user links */}
            {state.users.length > 0 && (
              <div>
                <p style={{ fontSize: 12, color: "var(--text-muted)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 12 }}>All user links</p>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {state.users.map(u => (
                    <div key={u.id} style={{
                      background: "rgba(255,255,255,0.02)", border: "1px solid var(--border)",
                      borderRadius: 12, padding: "12px 16px",
                      display: "flex", alignItems: "center", gap: 12
                    }}>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <p style={{ fontSize: 14, fontWeight: 500 }}>{u.name || <span style={{ color: "var(--text-muted)", fontStyle: "italic" }}>No name</span>}</p>
                        <p style={{ fontSize: 11, color: "var(--text-muted)", fontFamily: "'DM Mono', monospace", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {baseUrl}/track?id={u.id}
                        </p>
                      </div>
                      <button
                        className="btn-ghost"
                        style={{ padding: "6px 12px", fontSize: 12 }}
                        onClick={() => copyLink(`${baseUrl}/track?id=${u.id}`)}
                      >Copy</button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ANALYTICS TAB */}
        {tab === "analytics" && (
          <div>
            <h3 style={{ fontFamily: "'Playfair Display', serif", fontSize: 22, marginBottom: 20 }}>Analytics Overview</h3>

            {/* KPI cards */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 14, marginBottom: 28 }}>
              {[
                { label: "Total visits", val: state.visitCount, color: "var(--gold)", emoji: "👁" },
                { label: "Registered users", val: state.users.length, color: "var(--emerald)", emoji: "👥" },
                { label: "Avg 7-day rate", val: `${state.users.length === 0 ? 0 : Math.round(state.users.reduce((a, u) => a + pct7(u), 0) / state.users.length)}%`, color: "#a78bfa", emoji: "📊" },
                { label: "Total habits", val: state.baseHabits.length, color: "#60a5fa", emoji: "📋" },
              ].map(k => (
                <div key={k.label} className="glass fade-in-up" style={{ borderRadius: 14, padding: 20 }}>
                  <p style={{ fontSize: 28, marginBottom: 4 }}>{k.emoji}</p>
                  <p style={{ fontSize: 26, fontWeight: 700, color: k.color, fontFamily: "'DM Mono', monospace" }}>{k.val}</p>
                  <p style={{ fontSize: 12, color: "var(--text-muted)", marginTop: 2 }}>{k.label}</p>
                </div>
              ))}
            </div>

            {/* User performance table */}
            {state.users.length > 0 && (
              <div className="glass" style={{ borderRadius: 16, overflow: "hidden" }}>
                <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--border)" }}>
                  <h4 style={{ fontSize: 14, fontWeight: 600 }}>User Performance</h4>
                </div>
                <table className="data-table" style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead>
                    <tr>
                      <th style={{ textAlign: "left" }}>User</th>
                      <th>7-day %</th>
                      <th>Today</th>
                      <th>Habits</th>
                      <th>Stars</th>
                      <th>Visits</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[...state.users].sort((a,b) => pct7(b) - pct7(a)).map(u => (
                      <tr key={u.id}>
                        <td>{u.name || <span style={{ color: "var(--text-muted)", fontStyle: "italic" }}>No name</span>}</td>
                        <td style={{ textAlign: "center" }}>
                          <span style={{ color: pct7(u) >= 70 ? "var(--emerald)" : pct7(u) >= 40 ? "var(--gold)" : "var(--rose)", fontFamily: "'DM Mono', monospace", fontWeight: 600 }}>
                            {pct7(u)}%
                          </span>
                        </td>
                        <td style={{ textAlign: "center", fontFamily: "'DM Mono', monospace" }}>
                          {(u.completions[todayKey()] || []).length}/{u.habits.length}
                        </td>
                        <td style={{ textAlign: "center", fontFamily: "'DM Mono', monospace" }}>{u.habits.length}</td>
                        <td style={{ textAlign: "center" }}>
                          {u.stars > 0 ? "★".repeat(u.stars) : <span style={{ color: "var(--text-muted)" }}>—</span>}
                        </td>
                        <td style={{ textAlign: "center", fontFamily: "'DM Mono', monospace", color: "var(--text-muted)" }}>
                          {u.visitCount || 1}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
