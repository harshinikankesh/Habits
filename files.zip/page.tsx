"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

export default function Home() {
  const router = useRouter();
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);

  return (
    <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center", padding: "0 20px" }}>
      <div className="orb" style={{ width: 500, height: 500, background: "var(--gold)", top: -150, right: -100, opacity: 0.08 }} />
      <div className="orb" style={{ width: 400, height: 400, background: "var(--emerald)", bottom: -100, left: -100, opacity: 0.06 }} />

      <div className={mounted ? "fade-in-up" : ""} style={{ position: "relative", zIndex: 1 }}>
        <div style={{ fontSize: 60, marginBottom: 20 }} className="float">✦</div>
        <h1 style={{ fontFamily: "'Playfair Display', serif", fontSize: 42, fontWeight: 700, marginBottom: 12 }}>
          HabitForge
        </h1>
        <p style={{ color: "var(--text-muted)", fontSize: 16, maxWidth: 400, margin: "0 auto 36px", lineHeight: 1.6 }}>
          This is a private habit tracking platform. You need an invitation link to access your tracker.
        </p>
        <p style={{ fontSize: 13, color: "var(--text-muted)" }}>
          Are you the admin?{" "}
          <a href="/admin" style={{ color: "var(--gold)", textDecoration: "none", fontWeight: 500 }}>
            Go to Admin Console →
          </a>
        </p>
      </div>
    </div>
  );
}
