// ============================================================
// HabitForge — Unified Data Store (Vercel KV or in-memory)
// ============================================================

export type Habit = {
  id: string;
  label: string;
  emoji: string;
  category: string;
};

export type UserRecord = {
  id: string;           // nanoid — the "secret link" token
  name: string;
  joinedAt: string;     // ISO date
  allowedToSeeAdmin: boolean;  // can they see the creator's stats?
  habits: Habit[];      // customised habit list for this user
  completions: Record<string, string[]>; // date → habit IDs completed
  stars: number;        // 0-5 stars awarded by admin
  starNote: string;
  visitCount: number;
};

export type AdminState = {
  visitCount: number;   // total anonymous link visits
  baseHabits: Habit[];
  users: UserRecord[];
};

// ——— Default master habit set ———
export const DEFAULT_HABITS: Habit[] = [
  { id: "h1",  label: "Morning Meditation",  emoji: "🧘", category: "Mind"   },
  { id: "h2",  label: "Read 20 Pages",        emoji: "📖", category: "Mind"   },
  { id: "h3",  label: "Drink 2L Water",       emoji: "💧", category: "Body"   },
  { id: "h4",  label: "Exercise 30 min",      emoji: "🏋️", category: "Body"   },
  { id: "h5",  label: "No Social Media",      emoji: "📵", category: "Focus"  },
  { id: "h6",  label: "Sleep by 10:30 PM",    emoji: "🌙", category: "Rest"   },
  { id: "h7",  label: "Gratitude Journal",    emoji: "✍️", category: "Mind"   },
  { id: "h8",  label: "Cold Shower",          emoji: "🚿", category: "Body"   },
];

// ——— Server-side KV helpers ———
// We lazily import @vercel/kv only on the server so the
// browser bundle never includes it.

async function getKV() {
  const { kv } = await import("@vercel/kv");
  return kv;
}

const ADMIN_KEY = "hf:admin";

export async function loadAdminState(): Promise<AdminState> {
  try {
    const kv = await getKV();
    const data = await kv.get<AdminState>(ADMIN_KEY);
    if (data) return data;
  } catch (_) {}
  // Seed defaults
  return {
    visitCount: 0,
    baseHabits: DEFAULT_HABITS,
    users: [],
  };
}

export async function saveAdminState(state: AdminState): Promise<void> {
  try {
    const kv = await getKV();
    await kv.set(ADMIN_KEY, state);
  } catch (_) {}
}

export function todayKey(): string {
  return new Date().toISOString().slice(0, 10);
}
